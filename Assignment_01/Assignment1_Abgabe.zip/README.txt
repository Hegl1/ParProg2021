Group members:
Hosp Tobias, Huber Marcel, Klotz Thomas

Python-file:
Creates the plots and data tables for the different variations of the programs.